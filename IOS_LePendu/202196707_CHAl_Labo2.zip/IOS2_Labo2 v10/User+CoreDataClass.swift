//
//  User+CoreDataClass.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-18.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {
    
    

}
