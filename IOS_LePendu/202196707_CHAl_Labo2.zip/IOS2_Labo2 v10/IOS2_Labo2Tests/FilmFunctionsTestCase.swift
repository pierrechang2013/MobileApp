//
//  FilmFunctionsTestCase.swift
//  IOS2_Labo2Tests
//
//  Created by Liang Chang (Étudiant) on 2022-05-26.
//

import XCTest
@testable import IOS2_Labo2
class FilmFunctionsTestCase: XCTestCase {
    
    let ff = FilmFunctions();

    func testGiveString_WhenIncludeEspace_ThenRetrunEspacePositions(){
        let str = "a   d f d yuyuu i"
        print(ff.getCharPosition(str," "))
        
    }

}
