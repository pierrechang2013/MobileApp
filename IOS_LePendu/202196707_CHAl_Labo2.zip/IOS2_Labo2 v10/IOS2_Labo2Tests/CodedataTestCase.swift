//
//  CodedataTestCase.swift
//  IOS2_Labo2Tests
//
//  Created by Liang Chang (Étudiant) on 2022-05-18.
//

import XCTest
@testable import IOS2_Labo2

class CodedataTestCase: XCTestCase {

    func testGivenAUserDetailObj_whenInput_ThenSuccess(){
        
    }

}
