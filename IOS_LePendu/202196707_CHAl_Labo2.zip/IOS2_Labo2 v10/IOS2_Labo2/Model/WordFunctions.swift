//
//  File.swift
//  ISO2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-13.
//

import Foundation

class WordFunctions{
    
    
    func isFitSomeLetter(_ letter:String,_ word:String,_ wordNow: inout String) ->(Bool,String) {
        
        var bool = false
        //var newStr = ""
        var i = 0
        var j = 0
        print("word : \(word)")
        for index in word.indices {

            
            print("word \(index): \(word[index])")
            print("letter: \(letter)")
            if(word[index] == wordNow[index]){
                
            }else if(String(word[index]) == letter){
                
                let startIndex = wordNow.index(wordNow.startIndex, offsetBy:i)
                
                let endIndex = wordNow.index(wordNow.startIndex, offsetBy:i)
                
                let  range = startIndex...endIndex
                wordNow.replaceSubrange(range, with:letter)
                j = j + 1
                //bool = true
                //break;
            }
            
            i = i+1
            
        }
        if(j>0){
            bool = true
        }
        print(wordNow)
        return (bool,wordNow)
    }
    
    func countPoint(_ point:Int,_ times:Int) -> Int{
        
        var result = 0;
        
        if(times==0){
            result = point
        }else if(times<=2){
            result = point-times*1
        }else if(times<=4){
            result = point-times*2
        }else if(times == 5){
            result = point - 3*times
        }else if(times ==  6){
            result = 0
        }
        print("new points is \(result)")
        return  result;
        
        
    }
    
    func getRandomNum(_ length:Int)->Int{
        
        let randomNum = Int(arc4random_uniform(UInt32(length)))
        
        return randomNum
        
    }
    
    func getRandomNums(_ length:Int,_ times:Int)->[Int]{
        
        var numbers:[Int] = []
        var i = 0;
        
        while i < times {
            
            let rn = getRandomNum(length)
            if(!numbers.contains(rn)){
                numbers.insert(rn,at:i)
                i = i+1
            }else{
                print("same,no insert")
            }
            
        }
        print("???????????\(numbers)")
        
        return  numbers
        
    }
    
    func replaceLetterToSymbole(_ word:inout String,_ place:Int,_ symbole:String)->String {
        var i = 0
        
        for _ in word.indices {
            
            //newStr.append(wordNow[index])
            
            if(i == place){
                
                let startIndex = word.index(word.startIndex, offsetBy:i)
                
                let endIndex = word.index(word.startIndex, offsetBy:i)
                
                let  range = startIndex...endIndex
                word.replaceSubrange(range, with:symbole)
                
                break
                
            }
            
            i = i+1
        }
        
        return word
    }
    
    
    func getWord()->String{
        var result = ""
        //        print("0000000000000")
        let session = URLSession.shared
        let url = URL(string: "https://random-word-api.herokuapp.com/word")!
        let task = session.dataTask(with: url, completionHandler: { data, response, error in
            //如果有错误
            if let error = error{
                //error.localizedDescription
                //todo 对错误进行操作
                print(" \(error.localizedDescription)")
                return
            }
            //如果没有有响应，并且响应返回码不为200
            guard let httpResponse  = response as? HTTPURLResponse,httpResponse.statusCode == 200 else{
                //todo 对错误进行操作
                
                return
                
            }
            //如果没有数据对象
            guard let data1 = data else{
                print("no data")
                
                return
            }
            // Serialize the data into an object
            do {
                //                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                result = String(data:data1, encoding: String.Encoding.utf8) ?? "1111"
                
                
            } catch {
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
            
        })
        task.resume()
        
        
        return  result
    }
    
    func isUserExist(_ userName:String)->(Bool,Int){
        
        var bool = false
        var point = 0
        
        let userDefaults = UserDefaults.standard
        
        let dic  = userDefaults.value(forKey: userName) as? NSDictionary
 
        if dic == nil {
            
            
            print("this user dosen't exist")
            
        }else{
            point = dic?["point"] as! Int
            bool = true
        }

        return (bool,point)
    }
    
    
    func saveUser(_ user:User){
        
        let dic:Dictionary<String,Any> = ["point":user.point,"gameType":1]
        let userDefaults = UserDefaults.standard
        let result = self.isUserExist(user.name)
        
        if(result.0){//exist
            
            if result.1 <= user.point{
                
                print("user default no update")
            }else { userDefaults.setValue(dic, forKey:user.name)
                userDefaults.synchronize()
            
            }
            
        }else{
            
            userDefaults.setValue(dic, forKey:user.name)
                userDefaults.synchronize()
        }
        
    }
    
    func getAllUsers()->[User]{
        
        var users:[User] = []
        
        let userDefaults = UserDefaults.standard
        let dics = userDefaults.dictionaryRepresentation()
        for key in dics {
            
            
            
            if let dic = userDefaults.value(forKey: key.key) as? NSDictionary  {
                var user = User()
                print("!!!!!!!!!!!!!!!!\(key)")
                user.name = key.key as! String
                user.point = dic["point"] as! Int
                user.gameType = 1
                users.append(user)
                
            }
            

        }
        
        users = users.sorted{$0.point>$1.point}
        
        
        
        return users
    }
    
    func getUsers()->[User]{
        
        var users:[User] = []
        
        
        let userDefaults = UserDefaults.standard
        let dics = userDefaults.dictionaryRepresentation()
        
        for key in dics{
            
            if let dic = userDefaults.value(forKey: key.key) as? NSDictionary  {
                var user = User()
                print("!!!!!!!!!!!!!!!!\(key)")
                
                
                if(dic["gameType"] as! Int == 1){
                    
                    var user = User()
                    user.name = key.key 
                    user.point = dic["point"] as! Int
                    user.gameType = 1
                    users.append(user)
                }
            }
            
        }
        
        users = users.sorted{$0.point>$1.point}
        //        var newUsers:[User] = []
        if(users.count>=5){
            users = Array(users[0...4])
        }else{
            
        }
        
        return users
    }
    
    func updateUser(_ name:String,_ point:Int){
        var userNow = UserDefaults.standard.value(forKey: name) as? User
        
        if userNow == nil{
            var user = User();
            user.name = name
            user.point = point
            user.gameType = 1
            UserDefaults.standard.setValue(user, forKey: name)
        }else{
            var user = UserDefaults.value(forKey: name) as! User
            
            user.point = point
            UserDefaults.standard.setValue(user, forKey: name)
        }
        
        
        
    }
    
    
    //Todo getCurrentPoint
    //Todo saveUserInfo(_ name:String, point:Int)
    
    
    
    
}
