//
//  User.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-18.
//

import Foundation

struct User {
    var name = ""
    var point = 0
    var gameType = 0
}
