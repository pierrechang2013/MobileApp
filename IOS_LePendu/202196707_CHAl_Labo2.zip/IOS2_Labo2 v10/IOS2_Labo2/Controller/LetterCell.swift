//
//  LetterCell.swift
//  ISO2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-13.
//

import UIKit

class LetterCell: UICollectionViewCell {
    
    @IBOutlet weak var letterCellView: UILabel!
//    override init(frame: CGRect) {
//            super.init(frame: frame)
//
//        self.letterCellView.backgroundColor = UIColor.orange
//
//        }
//
//
//    required init?(coder aDecoder: NSCoder) {
//        super.init(coder: aDecoder)
//    }


    
    override var isSelected: Bool {
        didSet {
            if isSelected {
//                self.letterCellView.backgroundColor = UIColor.red
                self.letterCellView.isHidden = true
//                self.letterCellView.isEnabled = false
                
            } else {
                // animate deselection
            }
        }
    }
    
}
