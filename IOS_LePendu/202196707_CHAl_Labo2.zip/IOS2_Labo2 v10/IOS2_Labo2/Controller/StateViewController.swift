//
//  StateViewController.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-21.
//

import UIKit

class StateViewController: UIViewController, UITableViewDelegate,UITableViewDataSource{
    
    var isWordGame = true
    var users = [User]()
    let wf = WordFunctions()
    let ff = FilmFunctions()
    
    @IBOutlet weak var segment: UISegmentedControl!
    
    @IBAction func chooseSegment(_ sender: UISegmentedControl) {
//        print("chooseSegment")
        isWordGame = segment.selectedSegmentIndex == 0 ? true:false
        
        
        if(isWordGame){
            users = wf.getUsers()
        }else{
            users = ff.getUsers()
        }
        //refresh data
        
        recordTV.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let everyUser = self.users[indexPath.row]
        let cell = recordTV.dequeueReusableCell(withIdentifier: "item",for:indexPath) as! ItemTableViewCell
        
        cell.itemLabel.text = "Nom:\(everyUser.name),Resultat:\(everyUser.point)"
        
        return cell
    }
    

    @IBOutlet weak var recordTV: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        recordTV.delegate = self
        recordTV.dataSource = self
        
        if(isWordGame){
            users = wf.getUsers()
        }else{
            users = ff.getUsers()
            self.segment.selectedSegmentIndex = 1
        }
        
        
        
        
    }
    

    

}
