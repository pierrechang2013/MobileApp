//
//  LetterCell.swift
//  ISO2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-13.
//

import UIKit

class LetterCell: UICollectionViewCell {
    
    @IBOutlet weak var letterCellView: UILabel!
}
