//
//  FilmViewController.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-22.
//

import UIKit

class FilmViewController : UIViewController,UITextFieldDelegate {
    
    var errorTimes = 0
    let ff  = FilmFunctions()
    var filmDetail = [String:Any]()
    var points = 0
    @IBOutlet weak var infoTV: UITextView!
    
    @IBOutlet weak var noticTV: UITextView!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    @IBOutlet weak var pointTV: UITextView!
    
    @IBOutlet weak var filmNameTF: UITextField!
    
    @IBAction func guess(_ sender: UIButton) {
        self.errorTimes =  self.errorTimes + 1
        let filmNameInput =  self.filmNameTF.text?.lowercased()
//        print(filmNameInput?.lowercased().trimmingCharacters(in: CharacterSet.whitespaces))
        
        let filmName = self.filmDetail["Title"] as? String ?? "no Name"
        
        if(self.errorTimes >= 6){
            self.updateFilm()
            
        }else if(self.errorTimes<6 && filmNameInput == filmName.trimmingCharacters(in:CharacterSet.whitespaces).lowercased()){
            points = points + ff.countPoint(20, self.errorTimes)
            self.pointTV.text = String(points)
            self.updateFilm()
            
        }else  if(self.errorTimes<6 && filmNameInput != filmName.trimmingCharacters(in:CharacterSet.whitespaces).lowercased()){
            
            var result = ""
            
            switch self.errorTimes{
            
            case 2:
                
                result.append(ff.getNotice(self.filmDetail, 2))
                self.noticTV.text = result
                break
            case 4:
                result.append(ff.getNotice(self.filmDetail, 2))
                result.append(ff.getNotice(self.filmDetail, 4))
                self.noticTV.text = result
                break
            case 5:
                result.append(ff.getNotice(self.filmDetail, 2))
                result.append(ff.getNotice(self.filmDetail, 4))
                result.append(ff.getNotice(self.filmDetail, 5))
                self.noticTV.text = result
                break
            
            default:
               
                break
            }
            
            
            self.errorLabel.text = "\(self.errorTimes)/6"
            
            
        }

        
    
}
@IBAction func restart(_ sender: UIButton) {
//    print("###################")
    updateFilm()
}


@IBAction func finish(_ sender: UIButton) {
}

    @IBAction func toState(_ sender: UIButton) {
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //某个textview失去了响应者，即收起键盘了
        self.filmNameTF.resignFirstResponder()
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //或注销当前view(或它下属嵌入的text fields)的first responder 状态，即可关闭其子控件键盘
        //self.playName?.endEditing(false)
        self.filmNameTF?.endEditing(false)
                    return true
                }
    

override func viewDidLoad() {
    super.viewDidLoad()
    
    //        print("@@@@@@@@@@@@@@@@@@")
    self.filmNameTF.delegate = self
    updateFilm()
    
}

func updateFilm()  {
    
    let randomNum = Int(arc4random_uniform(UInt32(55252)))
    let url = URL(string:"https://www.omdbapi.com/?i=tt00\(randomNum)&apikey=e0a35fb0")!
    //        print(url)
    
    let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
        
        //如果有错误
        if let error = error{
            //error.localizedDescription
            //todo 对错误进行操作
            print(error)
            
            
        }
        //如果没有有响应，并且响应返回码不为200
        guard let httpResponse  = response as? HTTPURLResponse ,httpResponse.statusCode == 200  else{
            //todo 对错误进行操作
            //	                fatalError()
            
            return
        }
        
        
        //            guard let film = try? JSONDecoder().decode(  Film.self, from:data!) else{
        //
        //                fatalError("No json data")
        //
        //            }
        
        guard let film = try? JSONSerialization.jsonObject(with: data!, options:[]) as? [String:Any] else{
            
            print("No json data")
            return
        }
        
         
        guard film["Title"] != nil  else {
            self.updateFilm()
            return
        }
        
        self.filmDetail =  film
        
        // 将data转成字符串输出
        //            let str = String(data:data1, encoding: String.Encoding.utf8)
        //print(str as Any)
        DispatchQueue.main.async {
            self.errorTimes = 0
            self.infoTV.text = "Writer:\(film["Writer"]as? String ?? "")\n Language:\(film["Language"]as? String ?? "")\n Country:\(film["Country"]as? String ?? "")\n Year:\(film["Year"]as? String ?? "")"
            self.errorLabel.text = "0/6"
            self.noticTV.text = ""
            self.filmNameTF.text = ""
            
        }
        
        
        print(film["Title"])
        print(film["Actors"])
        print(film["Director"])
        print(film["Genre"])
        print(film["Released"])
        /*
         Country,Language,Writer,Year
         */
        print(film["Ratings"])
        
        if let arr = try? film["Ratings"] as?  NSArray {
            for ar in arr{
                if let a  = try? ar as! NSDictionary{
                    print(a["Source"])
                    print(a["Value"])
                }
            }
            
        }
        
        
    }
    
    task.resume();
    
}
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "saveNameFilm", let destination = segue.destination as? SaveFilmViewController{
            
            destination.point = self.pointTV.text
        }else if segue.identifier == "filmState", let destination = segue.destination as? StateViewController{
            
            destination.isWordGame = false
        }
    }


}
