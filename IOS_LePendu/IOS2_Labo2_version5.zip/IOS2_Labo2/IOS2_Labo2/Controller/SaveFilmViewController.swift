//
//  SaveViewController.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-18.
//

import UIKit

class SaveFilmViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var infoTV: UITextView!
    var point = "0"
    
    let ff = FilmFunctions()
    
    @IBOutlet weak var nameTF: UITextField!
    @IBAction func cancel(_ sender: UIButton) {
        
        
        self.dismiss(animated: true,completion: nil)
    }
    
    
    @IBAction func save(_ sender: UIButton) {
//        self.navigationController?.popViewController(animated: true)
        var user = User()
        
        guard let  name =  nameTF.text    else{
            nameTF.text = "nil impossible"
            return
        }
        
        guard name.count > 0  else {
            nameTF.text = "nil impossible"
            return
        }
        
        
        user.name = name
        user.point = Int(point)!
        
        ff.saveUser(user)
//        saveAlert();
//        self.dismiss(animated: true,completion: nil)
//        navigationController?.popToViewController(UIViewController, animated: <#T##Bool#>)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        infoTV.text = "Felicitation vous avez recu \(point),entrez votre nom a saugder!!!"
        self.nameTF.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //某个textview失去了响应者，即收起键盘了
        self.nameTF.resignFirstResponder()
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //或注销当前view(或它下属嵌入的text fields)的first responder 状态，即可关闭其子控件键盘
        //self.playName?.endEditing(false)
        self.nameTF?.endEditing(false)
                    return true
                }
    
    func saveAlert() {
                var alertController = UIAlertController(title: "Message", message: "Reussir a saugarder ", preferredStyle: UIAlertController.Style.alert)
                 
                 
                var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default) {
                    (action: UIAlertAction!) -> Void in
                    print("press ok already")
                }
                
                alertController.addAction(okAction)
                
                self.present(alertController, animated: true, completion: nil)
            }
    
    //before segue,execute it
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "justice"{
//
//            if let destination = segue.destination as? SuccessVC{
//
//                destination.text = "Login Success"
//            }
//
//
//
//        }
    }

    

}
