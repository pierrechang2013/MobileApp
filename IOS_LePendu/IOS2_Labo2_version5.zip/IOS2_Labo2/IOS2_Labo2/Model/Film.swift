////
////  Film.swift
////  IOS2_Labo2
////
////  Created by Liang Chang (Étudiant) on 2022-05-22.
////
//
//import Foundation
//import UIKit
//
//class Film:NSObject, Codable{
//    var Title:String
//    var Year:String
//    var Released:String
//    var Genre:String
//    var Ratings:[Rating]
//    var Director:String
//    var Actors:String
//    /*
//     {"Title":"Carmencita","Year":"1894","Rated":"Not Rated","Released":"10 Mar 1894","Runtime":"1 min","Genre":"Documentary, Short","Director":"William K.L. Dickson","Writer":"N/A","Actors":"Carmencita","Plot":"Performing on what looks like a small wooden stage, wearing a dress with a hoop skirt and white high-heeled pumps, Carmencita does a dance with kicks and twirls, a smile always on her face.","Language":"None","Country":"United States","Awards":"N/A","Poster":"https://m.media-amazon.com/images/M/MV5BZmUzOWFiNDAtNGRmZi00NTIxLWJiMTUtYzhkZGRlNzg1ZjFmXkEyXkFqcGdeQXVyNDE5MTU2MDE@._V1_SX300.jpg","Ratings":[{"Source":"Internet Movie Database","Value":"5.7/10"}],"Metascore":"N/A","imdbRating":"5.7","imdbVotes":"1,874","imdbID":"tt0000001","Type":"movie","DVD":"N/A","BoxOffice":"N/A","Production":"N/A","Website":"N/A","Response":"True"}
// 
//     */
//    
//}
//
//class Rating:NSObject,Codable{
//    var Source:String
//    var Value:String
//
//}
