	//
//  UserDetail+CoreDataProperties.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-18.
//
//

import Foundation
import CoreData


extension UserDetail {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<UserDetail> {
        return NSFetchRequest<UserDetail>(entityName: "UserDetail")
    }

    @NSManaged public var name: String?
    @NSManaged public var point: Int16
    @NSManaged public var gameType: Int16

}

extension UserDetail : Identifiable {

}
