//
//  FileFunctions.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-21.
//

import Foundation
      
class FilmFunctions{
    
//    func getFilm(){
//        var result:Film
//        
//        let randomNum = Int(arc4random_uniform(UInt32(55252)))
//        let url = URL(string:"http://www.omdbapi.com/?i=tt"+String(randomNum))!;
//        
//        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
//            
//            //如果有错误
//            if let error = error{
//                //error.localizedDescription
//                //todo 对错误进行操作
//                
//                return
//            }
//            //如果没有有响应，并且响应返回码不为200
//            guard let httpResponse  = response as? HTTPURLResponse,httpResponse.statusCode == 200 else{
//                //todo 对错误进行操作
//                return
//                
//            }
////            //如果没有数据对象
////            guard let data1 = data else{
////                print("no data")
////                return
////            }
////
//            //对json对象进行操作
//            
//            guard let film = try? JSONDecoder().decode(  Film.self, from:data!) else{
//                
//                fatalError("No json data")
//                
//            }
//            
//            result = film
//            
//            
//           
//            // 将data转成字符串输出
////            let str = String(data:data1, encoding: String.Encoding.utf8)
//            //print(str as Any)
//            
//            
////            print("长度： /(str)")
//            print(film.Title)
//            print(film.Actors)
//            print(film.Director)
//            print(film.Genre)
//            print(film.Released)
//            print(film.Ratings)
//            
//            
//            
//        }
//        
//        task.resume();
//        
//        return result
//    }
    
    func getUsers()->[User]{
        
        var users:[User] = []
        
        
        let userDefaults = UserDefaults.standard
        let dics = userDefaults.dictionaryRepresentation()
        
        for key in dics{
            
            if let dic = userDefaults.value(forKey: key.key) as? NSDictionary  {
//                print("!!!!!!!!!!!!!!!!\(key)")
                
                
                if(dic["gameType"] as! Int == 2){
                    
                    var user = User()
                    user.name = key.key
                    user.point = dic["point"] as! Int
                    user.gameType = 2
                    users.append(user)
                }
            }
            
        }
        
        users = users.sorted{$0.point>$1.point}
        //        var newUsers:[User] = []
        if(users.count>=5){
            users = Array(users[0...4])
        }else{
            
        }
        
        return users
    }
    
    func isUserExist(_ userName:String)->(Bool,Int){
        
        var bool = false
        var point = 0
        
        let userDefaults = UserDefaults.standard
        
        let dic  = userDefaults.value(forKey: userName) as? NSDictionary
 
        if dic == nil {
            
            
            print("this user dosen't exist")
            
        }else{
            point = dic?["point"] as! Int
            bool = true
        }

        return (bool,point)
    }
    
    func saveUser(_ user:User){
        
        let dic:Dictionary<String,Any> = ["point":user.point,"gameType":2]
        let userDefaults = UserDefaults.standard
        let result = self.isUserExist(user.name)
        
        if(result.0){//exist
            
            if result.1 <= user.point{
                
                print("user default no update")
            }else { userDefaults.setValue(dic, forKey:user.name)
                userDefaults.synchronize()
            
            }
            
        }else{
            
            userDefaults.setValue(dic, forKey:user.name)
                userDefaults.synchronize()
        }
        
        
        
        print(dic)
        
    }
    
    func returnList(_ str:String,_ splitSym:String)->[String]{
        
        let strList = str.components(separatedBy: splitSym)
//        print("!!!!!!!!!!!!!!!!!\(str)")
//        print(strList.count)
        
        
        return strList
        
    }
    
    func getListLimit(_ list:[String],_ limit:Int) -> [String] {
        
        var newList = [String]();
        
        if list.count <= limit {
            
            newList = list
            
        }else{
            newList = Array(list[0...limit])
        }
        
         
        
        return newList
    
    }
    
    func strListToString(_ list:[String]) -> String {
        
        var str = "";
        
        for i in list{
            
            str.append("\(i),")
        }
        
         
        
        return str
    
    }
    
    func countPoint(_ point:Int,_ times:Int) -> Int{
        
        var result = 0;
        
        if(times==0){
            result = point
        }else if(times<=2){
            result = point-times*1
        }else if(times<=4){
            result = point-times*2
        }else if(times == 5){
            result = point - 3*times
        }else if(times ==  6){
            result = 0
        }
        print("new points is \(result)")
        return  result;
        
        
    }
    
    func getNotice(_ filmDetail:[String:Any],_ errorTimes:Int)->String{
        var text = ""
        
        var textFor2 = "Released:"
        textFor2.append( filmDetail["Released"] as? String ?? "")
        textFor2.append("\n")
        
        var textFor4 = "Genre:"
        textFor4.append(filmDetail["Genre"] as? String ?? "")
        textFor4.append("\nRatings:")
        if let arr = try? filmDetail["Ratings"] as?  NSArray {
            for ar in arr{
                if let a  =   ar as? NSDictionary{
                    textFor4.append(a["Source"] as? String ?? "")
                    textFor4.append(",")
                    textFor4.append(a["Value"] as? String ?? "")
                     
                }
            }
            
        }
        textFor4.append("\n")
       
       
        var textFor5 = "Director:"
        textFor5.append(self.strListToString( self.getListLimit(self.returnList(filmDetail["Director"] as? String ?? "", ","), 2)))
        textFor5.append("\nActors:")
        textFor5.append(self.strListToString(self.getListLimit(self.returnList(filmDetail["Actors"] as? String ?? "", ","), 3)))
        
        //textFor5.append("\n")
        
        switch errorTimes {
        case 2:
            text = textFor2
            break
        case 4:
            text = textFor4
            break
        case 5:
            text = textFor5
            break
        default:
            break
        }
       
        return text
        
        
    }
    
    func replaceLettersToSymbole(_ name:inout String,_ place:Int,_ symbole:String)->String {
        var i = 0
        
        for _ in name.indices {
            
            //newStr.append(wordNow[index])
            
            if(i == place){
                
                let startIndex = name.index(name.startIndex, offsetBy:i)
                
                let endIndex = name.index(name.startIndex, offsetBy:i)
                
                let  range = startIndex...endIndex
                name.replaceSubrange(range, with:symbole)
                
                break
                
            }
            
            i = i+1
        }
        
        return name
    }
    
    func getRandomNum(_ length:Int)->Int{
        
        let randomNum = Int(arc4random_uniform(UInt32(length)))
        
        return randomNum
        
    }
    
    func getRandomNums(_ length:Int,_ times:Int,_ str:String)->[Int]{
        
        let espacePositions = self.getCharPosition(str, " ")
        
        var numbers:[Int] = []
        var i = 0;
        
        while i < times {
            
            let rn = getRandomNum(length)
            
            if(!numbers.contains(rn) && !espacePositions.contains(rn)){
                numbers.insert(rn,at:i)
                i = i+1
            }else{
                print("same,no insert")
            }
            
        }
        print("???????????\(numbers)")
        
        return  numbers
        
    }
    
    func getCharPosition(_ str:String,_ char:String)->[Int]{
        var positions:[Int] = []
        
        var i = 0
        for s in str{
            if String(s) == char {
            
                positions.append(i)
                
        }
            
            i = i + 1
            
        }
        
        return positions
    }
    
    
    func isFitSomeLetter(_ letter:String,_ fileName:String,_ fileNameNow: inout String) ->(Bool,String) {
        let letterUpp = letter.uppercased();
        
        let fileNameUpp = fileName.uppercased()
        
        var fileNameNowUpp = fileNameNow.uppercased()
        
        print("fileNameUpp : \(fileNameUpp)")
        print("fileNameNowUpp: \(fileNameNowUpp)")
        var bool = false
        //var newStr = ""
        var i = 0
        var j = 0
        print("fileNameUpp : \(fileNameUpp)")
        for index in fileName.indices {

            
            print("fileName \(index): \(fileName[index])")
            print("letter: \(letterUpp)")
            if(fileNameUpp[index] == fileNameNowUpp[index]){
                
            }else if(String(fileNameUpp[index]) == letterUpp){
                
                let startIndex = fileNameNowUpp.index(fileNameNowUpp.startIndex, offsetBy:i)
                
                let endIndex = fileNameNowUpp.index(fileNameNowUpp.startIndex, offsetBy:i)
                
                let  range = startIndex...endIndex
                fileNameNow.replaceSubrange(range, with:letter)
                j = j + 1
                //bool = true
                //break;
            }
            
            i = i+1
            
        }
        if(j>0){
            bool = true
        }
        print(fileNameNow)
        return (bool,fileNameNow)
    }
    
}
