//
//  UserDetail+CoreDataClass.swift
//  IOS2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-18.
//
//

import Foundation
import CoreData
import UIKit

@objc(UserDetail)
public class UserDetail: NSManagedObject {
    
    func inputData(_ user:UserDetail) -> () {
        //获取全局AppDelegate并且获得托管上下文
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        //因为后面要设置属性，所以需要强制转换为 as! Classmate
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "UserDetail", into: managedObjectContext) as! UserDetail
        
        newUser.name = user.name
        newUser.point = user.point
        newUser.gameType = user.gameType
        
        
        do {
            try managedObjectContext.save()
            print("save success")
        } catch {
            print("save error")
        }
    }

     
    func findData() -> () {
        
        let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        
        //实际上就是创建表对象
        let entity:NSEntityDescription? = NSEntityDescription.entity(forEntityName: "Classmate", in: managedObjectContext)
        
        //创建请求的设置
        let request = NSFetchRequest<UserDetail>(entityName: "UserDetail")
        request.fetchOffset = 0    //跳过的数据量，主要是多页查询用的
        request.fetchLimit = 10
        request.entity = entity
        
        //设置约束条件
        let predicate = NSPredicate(format: "name='xiaohua'", "")
        request.predicate = predicate
        
        //因为查询结果可能为空，所以动docatch捕获可能的异常
        do {
            let results:[AnyObject]? = try managedObjectContext.fetch(request)
            for classmate:UserDetail in results as! [UserDetail] {
                print("findOut:\(classmate.name!)")
            }
        } catch {
            print("didNotFind.")
        }
    }




        
        

}
