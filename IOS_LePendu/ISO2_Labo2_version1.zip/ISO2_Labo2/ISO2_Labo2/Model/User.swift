//
//  User.swift
//  ISO2_Labo2
//
//  Created by Liang Chang (Étudiant) on 2022-05-14.
//

import Foundation

struct User {
    var userName = ""
    var point = 0
}
